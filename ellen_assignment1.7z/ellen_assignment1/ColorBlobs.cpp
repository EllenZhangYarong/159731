//
//  ColorBlobs.cpp
//  ObjectLabelling
//
//  Created by 张亚荣 on 2018/3/18.
//  Copyright © 2018年 EllenAndAngel. All rights reserved.
//

#include "ColorBlobs.hpp"
#include <iostream>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>

using namespace std;
using namespace cv;


RNG rng(012345);


ColorBlobs::ColorBlobs(Mat image, vector<vector<Point>> setsOfBlobs){
    this->image = image;
    this->setsOfBlobs = setsOfBlobs;

};

Mat ColorBlobs::fillBlobs(){

    Mat d , drawing;
    this->image.copyTo(d);
    d.convertTo(drawing, CV_8UC3);

    for( auto blobs : this->setsOfBlobs ){
        Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );

        for( auto points : blobs){

            assert(points.y <= drawing.cols && points.x <= drawing.rows);

            Range xr(points.x, points.x+1);
            Range yr(points.y,points.y+1);
            drawing(xr,yr) = color;

        }

    }


    this->image = drawing;
    return this->image;
};


