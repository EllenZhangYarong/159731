//
//  main.cpp
//  ObjectLabelling
//
//  Created by 张亚荣 on 2018/3/18.
//  Copyright © 2018年 EllenAndAngel. All rights reserved.
//

#include <iostream>
#include <chrono>
#include <ctime>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#include "BlobDetector.hpp"
#include "ColorBlobs.hpp"
#include "SimpleMedianFilter.hpp"
#include "BinariseThreshold.hpp"
#include "SharpenEdge.hpp"



using namespace std;
using namespace cv;
using namespace chrono;

string type2str(int type);

Mat frame;//, image;
Mat imageSeries;

int main(int argc, const char * argv[])
{

    VideoCapture cap;
    cap.open(0);
    if (!cap.isOpened())
    {
        cout << "Failed to open camera" << endl;
        return 0;
    }
    cout << "Opened camera" << endl;
    namedWindow("WebCam", 1);
    cap.set(CV_CAP_PROP_FRAME_WIDTH, 640);
    //   cap.set(CV_CAP_PROP_FRAME_WIDTH, 960);
    //   cap.set(CV_CAP_PROP_FRAME_WIDTH, 1600);
    cap.set(CV_CAP_PROP_FRAME_HEIGHT, 480);
    //   cap.set(CV_CAP_PROP_FRAME_HEIGHT, 720);
    //   cap.set(CV_CAP_PROP_FRAME_HEIGHT, 1200);
    cap >> frame;
    printf("frame size %d %d \n",frame.rows, frame.cols);
    int key=0;

    double fps=0.0;
    while (1)
    {
        system_clock::time_point start = system_clock::now();
        //for(int a=0;a<10;a++){
        cap >> frame;
        if( frame.empty() )
            break;

        char printit[100];
        sprintf(printit,"%2.1f",fps);

        cvtColor(frame,imageSeries,CV_BGR2GRAY);

        //Code here
        BinariseThreshold bt(imageSeries);
        Mat btimage = bt.doBinariseImage();

        BlobDetector blobDetector(btimage);
        blobDetector.findingBlobs();

        int blobs = blobDetector.getNumberOfBlobs();
        cout << "Final blobs ---> " << blobs << endl;

        //sb: sets of blobs without empty vectors, just blobs
        vector<vector<Point>> sb = blobDetector.getFullBlobs();


        ColorBlobs colorBlobs(frame, sb);
        Mat filled = colorBlobs.fillBlobs();

        putText(filled, to_string(blobs) , cvPoint(100,30),
                FONT_HERSHEY_COMPLEX_SMALL, 2.0, cvScalar(0,255,255), 2, CV_AA);

        putText(filled, printit, cvPoint(10,30), FONT_HERSHEY_PLAIN, 2, cvScalar(255,255,255), 2, 8);
        imshow("WebCam", filled);

        key=waitKey(1);
        if(key==113 || key==27) return 0;//either esc or 'q'

        //}
        system_clock::time_point end = system_clock::now();
        double seconds = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
        //fps = 1000000*10.0/seconds;
        fps = 1000000/seconds;
        cout << "frames " << fps << " seconds " << seconds << endl;
    }


    return 0;
}

string type2str(int type)
{
    string r;

    uchar depth = type & CV_MAT_DEPTH_MASK;
    uchar chans = 1 + (type >> CV_CN_SHIFT);

    switch ( depth )
    {
    case CV_8U:
        r = "8U";
        break;
    case CV_8S:
        r = "8S";
        break;
    case CV_16U:
        r = "16U";
        break;
    case CV_16S:
        r = "16S";
        break;
    case CV_32S:
        r = "32S";
        break;
    case CV_32F:
        r = "32F";
        break;
    case CV_64F:
        r = "64F";
        break;
    default:
        r = "User";
        break;
    }

    r += "C";
    r += (chans+'0');

    return r;
}

